build --> g++ -Iinclude main.cpp src/*.cpp -o main
run  --> ./main   hoặc   main